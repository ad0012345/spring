package com.mango;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReserveDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReserveDemoApplication.class, args);
    }
}
