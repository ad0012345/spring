package com.mango.dao;

public interface MakeReservationDao {


}
